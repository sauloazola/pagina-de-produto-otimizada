const btnBuy = document.getElementById('btn-buy');
btnBuy.addEventListener('click', function() {
  // Aqui você pode adicionar a lógica para o clique no botão "Comprar"
  // por exemplo, exibir uma mensagem de sucesso, adicionar o produto ao carrinho, etc.
  console.log('Botão "Comprar" foi clicado!');
});
